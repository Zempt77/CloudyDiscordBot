import discord
import json
import random

client = discord.Client()

@client.event
async def on_ready():
  print('We are logged in as: ' + str(client.user.id))

@client.event
async def on_message(message):
  # makes sure that the message isn't from itself
  if message.author == client.user:
    return
  # opens trigger json file
  with open('trigger.json') as json_file:
    triggerDict = json.load(json_file)
  # checks if a trigger is in the message
  for i in triggerDict.keys():
    if i in message.content.lower():
      embed = discord.Embed(description = triggerDict[i].format(rand = random.randint(0, 100)), color = 0x2bd6d3)
      await message.channel.send(embed=embed)
      break
  # info command
  if message.content == 'c!info':
    newEmbed = discord.Embed(description='This is here to annoy you. Have fun!', color = 0x2bd6d3)
    await message.channel.send(embed=newEmbed)
  # makes sure its me sending add command
  if message.author.id == 372124383088476160:
    # add triggers
    if 'c!add' in message.content:
      tempList = message.content.split()
      responseList = tempList[2:]
      response = " ".join(responseList)
      triggerDict[tempList[1]] = response
      with open('trigger.json', 'w') as outfile:
        json.dump(triggerDict, outfile)
      await message.channel.send('Successfully added: ' + tempList[1] +' as trigger and: ' + response + ' as the response!')
    # remove triggers
    if 'c!remove' in message.content:
      tempList = message.content.split()
      try:
        triggerDict.pop(tempList[1])
        await message.channel.send('Successfully removed: ' + tempList[1] + ' from the list!')
      except:
        await message.channel.send('Not in trigger list')
        return
      with open('trigger.json', 'w') as outfile:
        json.dump(triggerDict, outfile)
  # danny detector
  if 'amogus' in message.content and message.author.id == 701169959673528381:
    newEmbed = discord.Embed(description = "You're not funny Danny.", color = 0x2bd6d3)
    await message.channel.send(embed=newEmbed)

    
client.run('i aint leaking my token')